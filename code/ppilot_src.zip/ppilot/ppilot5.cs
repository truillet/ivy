﻿/* ppilot5 v. 3.2
 * 
 * (c) Philippe Truillet
 * Last modified: 09/02/2021
 * 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Speech.Synthesis;

// bus ivy
using IvyBus;

namespace ppilot5
{
    public partial class ppilot5 : Form {

        SpeechSynthesizer _tts;
        private Ivy myBus;
        private String ivy_address = "127.255.255.255:2010";
        private String tts_lib = ""; // "Microsoft Hortense";
        String culture = "fr-FR";
        private String name = "ppilot5";

        private String[] t_args = null;

        public ppilot5(String[] args) {
            InitializeComponent();            
            this.WindowState = FormWindowState.Minimized;
            this.ShowInTaskbar = false; // nothing on taskbar

            this.t_args = args;

            if (t_args != null) {
                // gère les arguments
                for (int i = 0; i < this.t_args.Length; i = i + 2) {
                    if (t_args[i].CompareTo("-b") == 0)
                    {
                        this.ivy_address = t_args[i + 1];
                    }
                    if (t_args[i].CompareTo("-o") == 0)
                    {
                        // nom du moteur de synthèse à utiliser
                        this.tts_lib = t_args[i + 1];
                    }
                    if (t_args[i].CompareTo("-r") == 0)
                    {
                        this.name = t_args[i + 1];
                    }
                }
            }
            // ivy
            myBus = new Ivy(this.name, this.name + " is ready");
        
            try
            {
                myBus.Start(this.ivy_address);
                int regexp_id = myBus.BindMsg("^" + name + " Say=(.*)", receive_text);
                int regexp2_id = myBus.BindMsg("^" + name + " Command=(.*)", receive_command);
                int regexp3_id = myBus.BindMsg("^" + name + " Param=(.*):(.*)", receive_param);
                // new in v 3.1
                int regexp4_id = myBus.BindMsg("^" + name + " SaySSML=(.*)", receive_textSSML);
            }
            catch (IvyException e) { }

            _tts = new SpeechSynthesizer();
            // lancement de la synthèse

            /*
             * // some info to debug
             * notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
               notifyIcon1.BalloonTipText = "PPilot5 !";
               notifyIcon1.BalloonTipTitle = this.tts_lib;
               notifyIcon1.ShowBalloonTip(2000);
             */

            // charger la TTS passée en paramètre
            if (this.tts_lib.CompareTo("") != 0)
                _tts.SelectVoice(this.tts_lib);
            // sinon, c'est par défaut ...
            else
            {
                this.tts_lib = _tts.Voice.Name;
                _tts.SelectVoice(this.tts_lib);
                culture = _tts.Voice.Culture.Name;
            }
            // ajout 
            _tts.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(tts_SpeakCompleted);

        }

        // reçoit des ordres ivy
        /*
         * Fonction qui reçoit un message ivy
         *
         */
        private void receive_text(object sender, IvyMessageEventArgs e) {
            String[] args = e.GetArguments();
            // texte à synthétiser

            if (_tts.State == SynthesizerState.Ready)
                _tts.SpeakAsync(args[0]);
        }

        // new in v 3.1
        private void receive_textSSML(object sender, IvyMessageEventArgs e)
        {           
            String[] args = e.GetArguments();
            // texte à synthétiser
            String toSay = "<speak version=\"1.0\" xmlns=\"http://www.w3.org/2001/10/synthesis\" xml:lang=\"" + this.culture + "\">" + args[0] + "</speak>";
            if (_tts.State == SynthesizerState.Ready)
                _tts.SpeakSsmlAsync(toSay);
        }

        private void receive_command(object sender, IvyMessageEventArgs e) {
            // reçoit les commandes sur le réseau
            String[] args = e.GetArguments();

            String argument = args[0];

            if (argument.CompareTo("Stop") == 0) {
                _tts.SpeakAsyncCancelAll();
                // pas possible de stopper la synthèse
                //_tts.Pause();
                myBus.SendMsg(name + " Answer=Stopped");
            }
            else if (argument.CompareTo("Pause") == 0) {
                _tts.Pause();
                myBus.SendMsg(name + " Answer=Paused");
            }
            else if (argument.CompareTo("Resume") == 0) {
                _tts.Resume();
                myBus.SendMsg(name + " Answer=Resumed");
            }
            else if (argument.CompareTo("Quit") == 0) {
                if (myBus != null)
                    myBus.Stop();
                if (_tts != null)
                {
                    _tts.Dispose();
                }
                Close();
            }
        }

        private void receive_param(object sender, IvyMessageEventArgs e) {
            // reçoit les commandes
            String[] args = e.GetArguments();

            String commande = args[0];
            int value = Int32.Parse(args[1]);

            if (commande.CompareTo("Pitch") == 0) {
                // pas de pitch
            }
            else if (commande.CompareTo("Speed") == 0) {
                _tts.Rate = value;
                myBus.SendMsg(name + " Answer=SpeedValueSet:" + value);
            }
            else if (commande.CompareTo("Volume") == 0) {
                _tts.Volume = value;
                myBus.SendMsg(name + " Answer=SpeedVolumeSet:" + value);
            }
        }

        // handlers
        void tts_SpeakCompleted(object sender, SpeakCompletedEventArgs e) {
            if (e.Error != null)
            {
                myBus.SendMsg(name + " Answer=Finished");
            }
            return;
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e) {
            if (myBus != null)
                myBus.Stop();

            if (_tts != null)
            {
                _tts.Dispose();
            }
        }

        private void Form1_Load(object sender, EventArgs e) {
            // nothin to do here
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e) {
            // stop everything
            if (myBus != null)
                myBus.Stop();
            if (_tts != null) {
                _tts.Dispose();
            }
            System.Windows.Forms.Application.Exit();
        }
    }
}

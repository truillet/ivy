#!/usr/bin/env/python
# Bridge between ivy & ROS2 (python3)

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from ivy.ivy import IvyServer

## class IvyAgent
class IvyAgent(IvyServer):
    def __init__(self, name):
        IvyServer.__init__(self,name)
        self.name = name
        self.bind_msg(self.handle_message, '^ros2 msg=(.*)')
        self.bind_msg(self.handle_command, '^ros2 cmd=quit')
        self.start('127.255.255.255:2010')
        rclpy.init()
        self.ros_node = Bridge()
        rclpy.spin(self.ros_node)
        
    def handle_message(self, agent, arg):
        print ("[Agent %s] GOT MSG from %r" %(self.name, agent))
        msg = String()
        msg.data = str(arg)
        self.ros_node.publisher_.publish(msg)
        self.ros_node.get_logger().info('Publishing: "%s"' % msg.data)

    def handle_command(self, agent):
        # Destroy the node explicitly
        # (optional - otherwise it will be done automatically
        # when the garbage collector destroys the node object)
        self.ros_node.destroy_node()
        rclpy.shutdown()
        self.stop()

## class Bridge
class Bridge(Node):
    def __init__(self):
        super().__init__('bridge_ivy_ROS')
        self.publisher_ = self.create_publisher(String, 'ivy/message', 10)

    #def timer_callback(self):
    #    msg = String()
    #    msg.data = 'un message :)'
    #    self.publisher_.publish(msg)
    #    self.get_logger().info('Publishing: "%s"' % msg.data)
        

def main(args=None):
    agent=IvyAgent('Bridge_ivy_ROS')

if __name__ == '__main__':
    main()
